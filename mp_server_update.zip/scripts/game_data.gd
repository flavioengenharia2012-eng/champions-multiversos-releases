extends Node
## Autoload singleton: carrega dados estaticos (raças, armas, bônus) e guarda
## o progresso persistente da conta + a seleção da run atual.

var races: Array = []
var weapons: Array = []
var bonus_families: Array = []
var implemented_bonuses: Array = []
var enemy_types: Array = []
var stages: Array = []
var skins: Array = []
var equipment_items: Array = []
var equipment_slot_types: Array = []
var equipment_fusion_rules: Array = []
## Catalogo de bonus de item por categoria (arma=ataque, armadura=defesa,
## acessorio=elemental) — ver data/equipment.json:bonus_pool. Cada entrada
## tem "type" (mesmo vocabulario de player.gd:apply_bonus) e "base" (valor
## central; o valor sorteado varia +-ITEM_BONUS_VARIANCE em torno disso).
var equipment_bonus_pool: Dictionary = {}
const ITEM_BONUS_VARIANCE := 0.30

var selected_race_id: String = "kaidren"
var selected_weapon_id: String = "metralhadora"
var selected_skin_id: String = "nenhuma"

var is_online := false

const SAVE_PATH := "user://save_data.json"
const STAT_KEYS := ["dmg", "hp", "def", "vatk", "vel"]
const EXP_PER_LEVEL := 50.0
const POINTS_PER_LEVEL := 3

## Cada raca tem uma aparencia fixa (nao e escolha livre do jogador) —
## evita combinacoes visuais aleatorias sem sentido tematico. Usado tanto
## pela tela de selecao quanto pelo hub (pra mostrar o personagem certo).
const RACE_SKIN_MAP := {
	"kaidren": "golem_ice",
	"molgrath": "golem_earth",
	"ecliss": "goblin",
	"ferronn": "golem_forge",
	"xelvara": "seer",
	"pyravox": "minotaur_war",
}

## ---- Economia de itens (raridade, fusao, aprimoramento) ----
const RARITY_ORDER := ["Comum", "Raro", "Epico", "Lendario", "Mitico"]
const RARITY_STAT_MULT := 1.4
const ENHANCE_MAX_LEVEL := 10
const ENHANCE_BASE_COST := 25

var account_data: Dictionary = {
	"level": 1,
	"exp": 0.0,
	"unspent_points": 0,
	"points": { "dmg": 0, "hp": 0, "def": 0, "vatk": 0, "vel": 0 },
	"inventory": [],
	"equipped": {},
	"race_id": "",
	"weapon_id": "",
	"gold": 0
}

func _ready() -> void:
	races = _load_json("res://data/races.json").get("races", [])
	weapons = _load_json("res://data/weapons.json").get("weapons", [])
	bonus_families = _load_json("res://data/bonuses.json").get("families", [])
	enemy_types = _load_json("res://data/enemy_types.json").get("enemy_types", [])
	stages = _load_json("res://data/stages.json").get("stages", [])
	skins = _load_json("res://data/skins.json").get("skins", [])
	var equipment_data := _load_json("res://data/equipment.json")
	equipment_items = equipment_data.get("items", [])
	equipment_slot_types = equipment_data.get("slot_types", [])
	equipment_fusion_rules = equipment_data.get("fusion_rules", [])
	equipment_bonus_pool = equipment_data.get("bonus_pool", {})
	_flatten_bonuses()
	_load_account()

func _load_json(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		push_error("Arquivo nao encontrado: " + path)
		return {}
	var f := FileAccess.open(path, FileAccess.READ)
	var text := f.get_as_text()
	f.close()
	var result = JSON.parse_string(text)
	if typeof(result) != TYPE_DICTIONARY:
		push_error("JSON invalido em " + path)
		return {}
	return result

func _flatten_bonuses() -> void:
	implemented_bonuses.clear()
	for fam in bonus_families:
		for b in fam.get("bonuses", []):
			if b.get("implemented", false):
				var entry: Dictionary = b.duplicate(true)
				entry["family_id"] = fam.get("id", "")
				entry["family_name"] = fam.get("name", "")
				entry["color"] = fam.get("color", "cinza")
				entry["weight"] = float(fam.get("weight", 1.0))
				implemented_bonuses.append(entry)

func get_race(id: String) -> Dictionary:
	for r in races:
		if r.get("id") == id:
			return r
	return {}

func get_weapon(id: String) -> Dictionary:
	for w in weapons:
		if w.get("id") == id:
			return w
	return {}

func get_enemy_type(id: String) -> Dictionary:
	for e in enemy_types:
		if e.get("id") == id:
			return e
	return {}

func get_skin(id: String) -> Dictionary:
	for s in skins:
		if s.get("id") == id:
			return s
	return {}

## Retorna os dados do estagio pelo numero (1-based). Alem do ultimo estagio
## definido, a progressao entra em "loop infinito" reaproveitando os ultimos
## 10 estagios remixados, com dificuldade continuando a escalar via
## multiplicador extra. O ponto de loop e relativo ao fim do array, entao
## adicionar mais atos (ex. estagios 31-60) desloca o loop automaticamente.
func get_stage(number: int) -> Dictionary:
	if stages.is_empty():
		return {}
	if number <= stages.size():
		return stages[number - 1]
	var loop_len: int = min(10, stages.size())
	var loop_start: int = stages.size() - loop_len + 1
	var offset := (number - stages.size() - 1) % loop_len
	var base_stage: Dictionary = stages[loop_start - 1 + offset].duplicate(true)
	var extra_loops := int(float(number - stages.size() - 1) / float(loop_len)) + 1
	base_stage["difficulty_mult"] = float(base_stage.get("difficulty_mult", 1.0)) + extra_loops * 0.15
	base_stage["name"] = "%s (Eco %d)" % [base_stage.get("name", ""), extra_loops]
	return base_stage

## Sorteio ponderado (com reposicao) de um enemy_type id a partir de uma
## composicao de estagio: [{"id": "...", "weight": n}, ...]. Se um `rng`
## for passado (ex. o RNG reseedado por wave do wave_manager), o sorteio
## usa essa sequencia reproduzivel em vez do randf() global.
func pick_weighted_enemy_id(composition: Array, rng: RandomNumberGenerator = null) -> String:
	var total_weight := 0.0
	for c in composition:
		total_weight += float(c.get("weight", 1.0))
	if total_weight <= 0.0:
		return ""
	var roll := (rng.randf() if rng != null else randf()) * total_weight
	var acc := 0.0
	for c in composition:
		acc += float(c.get("weight", 1.0))
		if roll <= acc:
			return c.get("id", "")
	return composition.back().get("id", "")

## Sorteio ponderado sem reposicao, no estilo "Battle Mods" do jogo de
## referencia: familias com peso menor (ex. defensivos, estilo mod verde)
## aparecem com menor frequencia, tornando-as mais valiosas quando surgem.
func random_bonus_offers(count: int, exclude_ids: Array = []) -> Array:
	var pool: Array = []
	for b in implemented_bonuses:
		if not exclude_ids.has(b.get("id")):
			pool.append(b)

	var chosen: Array = []
	while chosen.size() < count and not pool.is_empty():
		var total_weight := 0.0
		for b in pool:
			total_weight += float(b.get("weight", 1.0))
		var roll := randf() * total_weight
		var acc := 0.0
		for i in range(pool.size()):
			acc += float(pool[i].get("weight", 1.0))
			if roll <= acc:
				chosen.append(pool[i])
				pool.remove_at(i)
				break
	return chosen

## ---- Progresso de conta (persistente entre execucoes) ----

func _load_account() -> void:
	if FileAccess.file_exists(SAVE_PATH):
		var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
		var text := f.get_as_text()
		f.close()
		var parsed = JSON.parse_string(text)
		if typeof(parsed) == TYPE_DICTIONARY:
			account_data = parsed
			if not account_data.has("inventory"):
				account_data["inventory"] = []
			if not account_data.has("equipped"):
				account_data["equipped"] = {}
			if not account_data.has("race_id"):
				account_data["race_id"] = ""
			if not account_data.has("weapon_id"):
				account_data["weapon_id"] = ""
			if not account_data.has("gold"):
				account_data["gold"] = 0
			_migrate_item_formats()
			_auto_assign_character_if_veteran()
			_ensure_weapon_item_equipped(String(account_data.get("weapon_id", "")))
			_sync_selection_from_account()
			return
	_save_account()

## Contas que ja tinham progresso real ANTES do campo race_id/weapon_id
## existir (nivel > 1, exp > 0, pontos gastos ou itens no inventario)
## nunca "escolheram" personagem oficialmente — sem isso, o jogo tratava
## esses jogadores veteranos como conta nova e mandava pra CharacterSelect
## toda vez que o fluxo de "Iniciar Run" nao era completado. Aqui a
## escolha e travada automaticamente com os padroes do jogo assim que
## detectamos progresso pre-existente, e o jogador pode trocar depois a
## qualquer momento pelo botao "Trocar Heroi" no hub.
func _account_has_real_progress() -> bool:
	return int(account_data.get("level", 1)) > 1 \
		or float(account_data.get("exp", 0.0)) > 0.0 \
		or int(account_data.get("unspent_points", 0)) > 0 \
		or not account_data.get("inventory", []).is_empty()

func _auto_assign_character_if_veteran() -> void:
	if has_chosen_character():
		return
	if _account_has_real_progress():
		account_data["race_id"] = selected_race_id
		account_data["weapon_id"] = selected_weapon_id
		_save_account()
		_sync_account_to_server()

## Migra formatos antigos de item: "inventory" era Array de String (so
## item_id) e "equipped" era {slot: item_id}. Converte pra instancias com
## uid/rarity/enhance_level/bonus_effects proprios, preservando o
## progresso de contas que jogaram antes dessa mudanca.
func _migrate_item_formats() -> void:
	var inv: Array = account_data.get("inventory", [])
	var id_to_first_uid: Dictionary = {}
	var migrated_inv: Array = []
	var changed := false
	for it in inv:
		if typeof(it) == TYPE_STRING:
			changed = true
			var new_item := {
				"uid": _generate_item_uid(),
				"item_id": it,
				"rarity": "Comum",
				"enhance_level": 0,
				"bonus_effects": [],
			}
			migrated_inv.append(new_item)
			if not id_to_first_uid.has(it):
				id_to_first_uid[it] = new_item["uid"]
		else:
			migrated_inv.append(it)
	if changed:
		account_data["inventory"] = migrated_inv

	var equipped: Dictionary = account_data.get("equipped", {})
	var migrated_equipped: Dictionary = {}
	var equipped_changed := false
	for slot in equipped.keys():
		var value = equipped[slot]
		if typeof(value) == TYPE_STRING and id_to_first_uid.has(value):
			migrated_equipped[slot] = id_to_first_uid[value]
			equipped_changed = true
		else:
			migrated_equipped[slot] = value
	if equipped_changed:
		account_data["equipped"] = migrated_equipped

func _generate_item_uid() -> String:
	return "it_%d_%d" % [Time.get_ticks_usec(), randi() % 100000]

## Verdadeiro assim que a conta ja tem raca+arma escolhidas (mesmo que so
## localmente, antes de logar) — usado pelo HubScreen pra decidir se pula
## a tela de selecao de personagem.
func has_chosen_character() -> bool:
	return String(account_data.get("race_id", "")) != "" and String(account_data.get("weapon_id", "")) != ""

## Chamado pela tela de selecao de personagem ao confirmar raca+arma.
## Fica fixo na conta (local + servidor) — nas proximas vezes o jogo pula
## direto pro hub com esse personagem, sem perguntar de novo. A arma
## escolhida vira um item de verdade no inventario, equipado no slot
## "arma" — sem esse item equipado o personagem simplesmente nao ataca.
func set_character(race_id: String, weapon_id: String) -> void:
	account_data["race_id"] = race_id
	account_data["weapon_id"] = weapon_id
	_ensure_weapon_item_equipped(weapon_id)
	_sync_selection_from_account()
	_save_account()
	_sync_account_to_server()

## Garante que a arma escolhida na criacao do personagem existe como item
## no inventario e esta equipada no slot "arma". So cria/equipa se o slot
## ainda estiver vazio — idempotente, seguro de chamar em migracoes de
## contas antigas (que tinham weapon_id mas nunca ganharam o item).
func _ensure_weapon_item_equipped(weapon_id: String) -> void:
	if weapon_id == "":
		return
	var equipped: Dictionary = account_data.get("equipped", {})
	if equipped.has("arma"):
		return
	var inv: Array = account_data.get("inventory", [])
	var uid := ""
	for it in inv:
		if it.get("item_id", "") == weapon_id and _is_raw_stack(it):
			uid = it.get("uid", "")
			break
	if uid == "":
		uid = _generate_item_uid()
		inv.append({
			"uid": uid,
			"item_id": weapon_id,
			"rarity": "Comum",
			"enhance_level": 0,
			"bonus_effects": [_roll_item_bonus(weapon_id)],
			"count": 1,
		})
		account_data["inventory"] = inv
	equipped["arma"] = uid
	account_data["equipped"] = equipped

## Stats base da arma equipada agora (slot "arma"), ou {} se nada estiver
## equipado — nesse caso o player.gd nao consegue atacar.
func get_equipped_weapon_data() -> Dictionary:
	var equipped: Dictionary = account_data.get("equipped", {})
	var uid: String = equipped.get("arma", "")
	if uid == "":
		return {}
	var inst := get_inventory_item(uid)
	if inst.is_empty():
		return {}
	return get_weapon(inst.get("item_id", ""))

## Raridade da instancia da arma equipada (nao do template estatico, que nao
## carrega raridade) — usado pelo brilho da arma na mao em player.gd.
func get_equipped_weapon_rarity() -> String:
	var equipped: Dictionary = account_data.get("equipped", {})
	var uid: String = equipped.get("arma", "")
	if uid == "":
		return ""
	return String(get_inventory_item(uid).get("rarity", "Comum"))

## Preenche selected_race_id/weapon_id/skin_id (usados por player.gd/main.gd
## pra montar a run) a partir do que esta salvo em account_data.
func _sync_selection_from_account() -> void:
	var race_id: String = String(account_data.get("race_id", ""))
	var weapon_id: String = String(account_data.get("weapon_id", ""))
	if race_id != "":
		selected_race_id = race_id
		selected_skin_id = RACE_SKIN_MAP.get(race_id, "nenhuma")
	if weapon_id != "":
		selected_weapon_id = weapon_id

func _save_account() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	f.store_string(JSON.stringify(account_data, "\t"))
	f.close()

## Chamado ao fim de uma run com o total de EXP ganho nas waves.
func add_account_exp(amount: float) -> int:
	account_data["exp"] = float(account_data.get("exp", 0.0)) + amount
	var levels_gained := 0
	while account_data["exp"] >= EXP_PER_LEVEL * account_data["level"]:
		account_data["exp"] -= EXP_PER_LEVEL * account_data["level"]
		account_data["level"] += 1
		account_data["unspent_points"] = int(account_data.get("unspent_points", 0)) + POINTS_PER_LEVEL
		levels_gained += 1
	_save_account()
	_sync_account_to_server()
	return levels_gained

func spend_point(stat_key: String) -> bool:
	if int(account_data.get("unspent_points", 0)) <= 0:
		return false
	if not STAT_KEYS.has(stat_key):
		return false
	account_data["unspent_points"] = int(account_data["unspent_points"]) - 1
	account_data["points"][stat_key] = int(account_data["points"].get(stat_key, 0)) + 1
	_save_account()
	_sync_account_to_server()
	return true

func get_account_points() -> Dictionary:
	return account_data.get("points", {})

## ---- Gold (moeda persistente, ganha por kill durante as waves) ----

func add_gold(amount: int) -> void:
	if amount <= 0:
		return
	account_data["gold"] = int(account_data.get("gold", 0)) + amount
	_save_account()
	_sync_account_to_server()

func spend_gold(amount: int) -> bool:
	if amount <= 0:
		return true
	if int(account_data.get("gold", 0)) < amount:
		return false
	account_data["gold"] = int(account_data["gold"]) - amount
	_save_account()
	_sync_account_to_server()
	return true

func get_gold() -> int:
	return int(account_data.get("gold", 0))

## ---- Equipamentos ----

## Armas agora tambem sao itens equipaveis (slot "arma"), mas moram em
## data/weapons.json com um formato proprio (damage_mult/base_fire_rate/
## etc., nao o {type,value} generico dos itens de armadura) — por isso o
## fallback aqui monta um template minimo (nome/descricao/slot) sob
## demanda em vez de duplicar os dados das armas num segundo arquivo.
func get_equipment_item(id: String) -> Dictionary:
	for it in equipment_items:
		if it.get("id") == id:
			return it
	var w := get_weapon(id)
	if not w.is_empty():
		return {
			"id": w.get("id"),
			"name": w.get("name", ""),
			"description": "%s — Vantagem: %s" % [w.get("profile", ""), w.get("advantage", "")],
			"slot": "arma",
		}
	return {}

## Slot -> categoria de bonus de item: arma=ataque; capacete/peitoral/
## luvas/botas=defesa; acessorio=elemental.
static func _bonus_category_for_slot(slot: String) -> String:
	if slot == "arma":
		return "ataque"
	if slot == "acessorio":
		return "elemental"
	return "defesa"

## Sorteia 1 bonus da categoria certa pro slot do item, com valor entre
## -30% e +30% do "base" da entrada (ex.: base 5% vira algo entre 3.5% e
## 6.5%) — mesma variacao pra qualquer atributo de item.
func _roll_item_bonus(item_id: String) -> Dictionary:
	var slot: String = String(get_equipment_item(item_id).get("slot", ""))
	var category := _bonus_category_for_slot(slot)
	var pool: Array = equipment_bonus_pool.get(category, [])
	if pool.is_empty():
		return {}
	var pick: Dictionary = pool[randi() % pool.size()]
	var base: float = float(pick.get("base", 0.0))
	var roll: float = base * (1.0 + randf_range(-ITEM_BONUS_VARIANCE, ITEM_BONUS_VARIANCE))
	return {"type": pick.get("type"), "value": roll}

## Combina 2 listas de bonus_effects: entradas do mesmo "type" tem os
## valores somados; tipos diferentes ficam lado a lado na lista final.
## Usado na fusao pra juntar os bonus dos 2 itens consumidos.
static func _merge_bonus_effects(a: Array, b: Array) -> Array:
	var merged: Array = []
	for eff in a:
		merged.append((eff as Dictionary).duplicate(true))
	for eff in b:
		var eff_type = eff.get("type")
		var found := false
		for m in merged:
			if m.get("type") == eff_type:
				m["value"] = float(m.get("value", 0.0)) + float(eff.get("value", 0.0))
				found = true
				break
		if not found:
			merged.append((eff as Dictionary).duplicate(true))
	return merged

## Chamado quando um inimigo dropa um item (ver wave_manager.gd) ou quando
## uma conta nova recebe o kit inicial. Todo item novo nasce Comum, +0, com
## 1 bonus aleatorio ja sorteado (ver _roll_item_bonus) — por isso cada
## copia agora e uma instancia propria (nao empilha mais por count: duas
## copias "Comum" podem ter bonus diferentes entre si).
func add_item_to_inventory(item_id: String) -> void:
	var inv: Array = account_data.get("inventory", [])
	inv.append({
		"uid": _generate_item_uid(),
		"item_id": item_id,
		"rarity": "Comum",
		"enhance_level": 0,
		"bonus_effects": [_roll_item_bonus(item_id)],
		"count": 1,
	})
	account_data["inventory"] = inv
	_save_account()
	_sync_account_to_server()

## ---- Negociacao em tempo real (Fase C.8) ----
## Os dois lados de uma troca sao aplicados de forma independente, cada
## cliente mexendo so na propria conta (o servidor dedicado apenas retransmite
## a proposta/resposta via RPC, sem tocar em banco de dados — ver
## multiplayer_room.gd:propose_trade/respond_trade). Por isso o item doado
## precisa viajar com o "snapshot" completo (rarity/enhance_level/
## bonus_effects), nao so o item_id: quem recebe cria uma instancia nova
## com esses mesmos atributos, ja que o uid so faz sentido na conta de origem.

## Remove 1 copia da instancia (uid) do inventario — decrementa "count" se for
## uma pilha, ou remove a entrada inteira se for a ultima copia.
func remove_item_from_inventory(uid: String) -> void:
	var inv: Array = account_data.get("inventory", [])
	for i in range(inv.size()):
		if inv[i].get("uid") != uid:
			continue
		var count: int = int(inv[i].get("count", 1))
		if count > 1:
			inv[i]["count"] = count - 1
		else:
			inv.remove_at(i)
		account_data["inventory"] = inv
		_save_account()
		_sync_account_to_server()
		return

## Adiciona uma instancia nova preservando raridade/aprimoramento/bonus de
## uma copia recebida de outro jogador (ao aceitar uma negociacao).
func add_full_item_instance(item_id: String, rarity: String, enhance_level: int, bonus_effects: Array) -> void:
	var inv: Array = account_data.get("inventory", [])
	inv.append({
		"uid": _generate_item_uid(),
		"item_id": item_id,
		"rarity": rarity,
		"enhance_level": enhance_level,
		"bonus_effects": bonus_effects,
		"count": 1,
	})
	account_data["inventory"] = inv
	_save_account()
	_sync_account_to_server()

## Uma instancia so pode empilhar se for uma copia "crua": Comum, +0, sem
## nenhum bonus extra de fusao (item fundido ou aprimorado e sempre unico).
func _is_raw_stack(inst: Dictionary) -> bool:
	return inst.get("rarity", "Comum") == "Comum" \
		and int(inst.get("enhance_level", 0)) == 0 \
		and inst.get("bonus_effects", []).is_empty()

## Retorna a instancia do inventario (dict com uid/item_id/rarity/
## enhance_level/bonus_effects/count) ou {} se o uid nao existir.
func get_inventory_item(uid: String) -> Dictionary:
	for it in account_data.get("inventory", []):
		if it.get("uid") == uid:
			return it
	return {}

## Separa 1 copia de uma pilha (count > 1) numa instancia individual nova
## (count 1) pra poder equipar/aprimorar so essa copia, sem afetar o resto
## da pilha. Se a instancia ja for individual (count <= 1), retorna o
## mesmo uid sem mudar nada.
func _split_one_from_stack(uid: String) -> String:
	var inv: Array = account_data.get("inventory", [])
	for i in range(inv.size()):
		if inv[i].get("uid") != uid:
			continue
		var count: int = int(inv[i].get("count", 1))
		if count <= 1:
			return uid
		inv[i]["count"] = count - 1
		var single: Dictionary = inv[i].duplicate(true)
		single["uid"] = _generate_item_uid()
		single["count"] = 1
		inv.append(single)
		account_data["inventory"] = inv
		return single["uid"]
	return uid

## Retorna o uid efetivamente equipado (pode ser diferente do uid passado
## se ele apontava pra uma pilha — nesse caso 1 copia e separada antes de
## equipar), ou "" se a instancia/template nao existir.
func equip_item(uid: String) -> String:
	uid = _split_one_from_stack(uid)
	var inst := get_inventory_item(uid)
	if inst.is_empty():
		return ""
	var template := get_equipment_item(inst.get("item_id", ""))
	if template.is_empty():
		return ""
	var equipped: Dictionary = account_data.get("equipped", {})
	equipped[template.get("slot")] = uid
	account_data["equipped"] = equipped
	_save_account()
	_sync_account_to_server()
	return uid

func unequip_item(slot: String) -> void:
	var equipped: Dictionary = account_data.get("equipped", {})
	equipped.erase(slot)
	account_data["equipped"] = equipped
	_save_account()
	_sync_account_to_server()

## Retorna os efeitos (mesmo formato de data/bonuses.json) de todos os itens
## equipados no momento, pra o player.gd aplicar em setup() igual um bonus.
## O valor de cada efeito base e escalado pela raridade da instancia
## (RARITY_STAT_MULT composto por tier) e pelo nivel de aprimoramento
## (+10% por nivel), alem dos bonus extras ganhos em fusoes.
func get_equipped_effects() -> Array:
	var effects: Array = []
	var equipped: Dictionary = account_data.get("equipped", {})
	for slot in equipped.keys():
		var inst := get_inventory_item(equipped[slot])
		if inst.is_empty():
			continue
		var template := get_equipment_item(inst.get("item_id", ""))
		if template.is_empty() or not template.has("effect"):
			continue
		var base_effect: Dictionary = template.get("effect")
		var rarity_idx: int = RARITY_ORDER.find(inst.get("rarity", "Comum"))
		if rarity_idx == -1:
			rarity_idx = 0
		var rarity_mult: float = pow(RARITY_STAT_MULT, rarity_idx)
		var enhance_mult: float = 1.0 + int(inst.get("enhance_level", 0)) * 0.10
		var effective: Dictionary = base_effect.duplicate(true)
		effective["value"] = float(base_effect.get("value", 0.0)) * rarity_mult * enhance_mult
		effects.append(effective)
		for bonus in inst.get("bonus_effects", []):
			effects.append(bonus)
	return effects

## ---- Fusao (combina copias iguais na mesma raridade -> proximo tier) ----

func _next_rarity(rarity: String) -> String:
	var idx := RARITY_ORDER.find(rarity)
	if idx == -1 or idx >= RARITY_ORDER.size() - 1:
		return ""
	return RARITY_ORDER[idx + 1]

func get_fusion_cost(rarity: String) -> int:
	for rule in equipment_fusion_rules:
		if rule.get("from") == rarity:
			return int(rule.get("cost", 0))
	return 0

## Conta quantas copias de (item_id, rarity) existem no inventario agora —
## usado pela FusionScreen pra saber se ja da pra fundir. Soma "count" de
## cada registro (uma pilha crua pode valer por varias copias).
func count_inventory_matches(item_id: String, rarity: String) -> int:
	var count := 0
	for it in account_data.get("inventory", []):
		if it.get("item_id") == item_id and it.get("rarity") == rarity:
			count += int(it.get("count", 1))
	return count

## Funde N copias (N = fusion_rules do tier atual) de (item_id, rarity) em
## 1 copia nova no proximo tier, com stats multiplicados e +1 bonus
## aleatorio novo. Retorna a instancia nova, ou {} se nao houver copias
## suficientes ou a raridade ja estiver no topo (Mitico).
func fuse_items(item_id: String, rarity: String) -> Dictionary:
	var next_rarity := _next_rarity(rarity)
	if next_rarity == "":
		return {}
	var cost := get_fusion_cost(rarity)
	if cost <= 0:
		return {}
	var inv: Array = account_data.get("inventory", [])
	if count_inventory_matches(item_id, rarity) < cost:
		return {}

	## Consome "cost" copias, possivelmente espalhadas por poucas pilhas —
	## uma pilha crua com count > cost so tem o count reduzido; uma pilha
	## totalmente consumida (ou uma instancia unica) e removida da lista.
	## Os bonus_effects de cada copia consumida sao combinados (mesmo tipo
	## soma os valores, tipos diferentes ficam lado a lado) via
	## _merge_bonus_effects, formando o bonus do item fundido.
	var remaining := cost
	var collected_bonuses: Array = []
	var removed_uids: Array = []
	var new_inv: Array = []
	for it in inv:
		if remaining > 0 and it.get("item_id") == item_id and it.get("rarity") == rarity:
			collected_bonuses.append(it.get("bonus_effects", []).duplicate(true))
			var c: int = int(it.get("count", 1))
			if c <= remaining:
				remaining -= c
				removed_uids.append(it.get("uid"))
				continue
			else:
				it["count"] = c - remaining
				remaining = 0
				new_inv.append(it)
				continue
		new_inv.append(it)

	var new_bonus: Array = []
	for b in collected_bonuses:
		new_bonus = _merge_bonus_effects(new_bonus, b)
	var new_item := {
		"uid": _generate_item_uid(),
		"item_id": item_id,
		"rarity": next_rarity,
		"enhance_level": 0,
		"bonus_effects": new_bonus,
		"count": 1,
	}
	new_inv.append(new_item)
	account_data["inventory"] = new_inv
	## Se o item fundido estava equipado, o slot fica vazio automaticamente
	## (a instancia antiga nao existe mais) — nao equipa o novo sozinho, o
	## jogador escolhe equipar de novo se quiser.
	var equipped: Dictionary = account_data.get("equipped", {})
	for slot in equipped.keys().duplicate():
		if removed_uids.has(equipped[slot]):
			equipped.erase(slot)
	account_data["equipped"] = equipped
	_save_account()
	_sync_account_to_server()
	return new_item

## ---- Aprimoramento (+1 a +10, custa Gold, chance decrescente) ----

func get_enhance_cost(target_level: int) -> int:
	return ENHANCE_BASE_COST * target_level * target_level

## Chance de sucesso (%) pra ir de level_before pro proximo nivel.
## Comeca em 90% (0->1) e cai linearmente ate 5% (9->10).
func get_enhance_chance(level_before: int) -> float:
	return 90.0 - float(clamp(level_before, 0, 9)) * (85.0 / 9.0)

## Sorteia o resultado de uma tentativa de aprimoramento na instancia (uid —
## se apontar pra uma pilha, 1 copia e separada antes, ver
## _split_one_from_stack) SEM aplicar nada ainda — o gold ja e gasto aqui
## (sucesso ou falha da tentativa em si), mas o nivel/atributo ganho so
## passam a integrar o item se confirm_enhance_attempt for chamado com
## confirmed=true (ver EnhanceScreen: dialogo Sim/Nao mostrando o atributo
## sorteado antes de commitar). Retorna um dict com "ok" (se a tentativa foi
## processada) e, quando ok, "uid" (resolvido, pode ter mudado por causa do
## split)/"success"/"rolled_stat"/"new_level"/"cost"/"chance".
func roll_enhance_attempt(uid: String) -> Dictionary:
	uid = _split_one_from_stack(uid)
	var inv: Array = account_data.get("inventory", [])
	var idx := -1
	for i in range(inv.size()):
		if inv[i].get("uid") == uid:
			idx = i
			break
	if idx == -1:
		return {"ok": false, "reason": "item_nao_encontrado"}
	var item: Dictionary = inv[idx]
	var level := int(item.get("enhance_level", 0))
	if level >= ENHANCE_MAX_LEVEL:
		return {"ok": false, "reason": "nivel_maximo"}
	var cost := get_enhance_cost(level + 1)
	if not spend_gold(cost):
		return {"ok": false, "reason": "gold_insuficiente", "cost": cost}
	var chance := get_enhance_chance(level)
	var success: bool = randf() * 100.0 < chance
	var rolled_stat := ""
	if success:
		rolled_stat = STAT_KEYS[randi() % STAT_KEYS.size()]
	return {
		"ok": true,
		"uid": uid,
		"success": success,
		"rolled_stat": rolled_stat,
		"new_level": level + 1,
		"cost": cost,
		"chance": chance,
	}

## Aplica (se confirmed=true e a rolagem teve sucesso) ou descarta o
## resultado de roll_enhance_attempt. Negar equivale a uma falha: nada e
## integrado ao item, e o gold ja gasto na rolagem nao e devolvido —
## "e considerado que o aprimoramento falhou" (pedido explicito do usuario).
func confirm_enhance_attempt(roll_result: Dictionary, confirmed: bool) -> void:
	if not roll_result.get("ok", false) or not roll_result.get("success", false) or not confirmed:
		return
	var uid: String = roll_result.get("uid", "")
	var inv: Array = account_data.get("inventory", [])
	var idx := -1
	for i in range(inv.size()):
		if inv[i].get("uid") == uid:
			idx = i
			break
	if idx == -1:
		return
	var item: Dictionary = inv[idx]
	item["enhance_level"] = int(roll_result.get("new_level", item.get("enhance_level", 0)))
	var stat_points: Dictionary = item.get("stat_points", {})
	var rolled_stat: String = roll_result.get("rolled_stat", "")
	if rolled_stat != "":
		stat_points[rolled_stat] = int(stat_points.get(rolled_stat, 0)) + 1
	item["stat_points"] = stat_points
	inv[idx] = item
	account_data["inventory"] = inv
	_save_account()
	_sync_account_to_server()

## Soma os "stat_points" (dmg/hp/def/vatk/vel) de todos os itens equipados
## agora — ganhos aleatorios de aprimoramento, permanentes enquanto o item
## estiver equipado. Usado por player.gd junto com GameData.get_account_points().
func get_equipped_stat_points() -> Dictionary:
	var totals: Dictionary = {}
	var equipped: Dictionary = account_data.get("equipped", {})
	for slot in equipped.keys():
		var inst := get_inventory_item(equipped[slot])
		if inst.is_empty():
			continue
		var stat_points: Dictionary = inst.get("stat_points", {})
		for key in stat_points.keys():
			totals[key] = int(totals.get(key, 0)) + int(stat_points[key])
	return totals

## ---- Sincronizacao com o backend de contas (chamado pelo LoginScreen) ----

## Chamado apos login/registro bem-sucedido. Busca account_data do servidor;
## se a conta do servidor estiver zerada e houver progresso local, oferece
## (automaticamente) importar o save local pra conta recem-criada.
func on_logged_in(_username: String) -> void:
	is_online = true
	NetworkClient.account_fetch_result.connect(_on_account_fetched, CONNECT_ONE_SHOT)
	NetworkClient.fetch_account()

func _on_account_fetched(success: bool, remote: Dictionary) -> void:
	if not success or remote.is_empty():
		return
	var remote_empty: bool = int(remote.get("level", 1)) <= 1 and float(remote.get("exp", 0.0)) == 0.0 and int(remote.get("unspent_points", 0)) == 0
	var local_has_progress: bool = int(account_data.get("level", 1)) > 1 or float(account_data.get("exp", 0.0)) > 0.0 or int(account_data.get("unspent_points", 0)) > 0
	if remote_empty and local_has_progress:
		NetworkClient.account_fetch_result.connect(_on_account_imported, CONNECT_ONE_SHOT)
		NetworkClient.import_account(account_data)
	else:
		_merge_remote_account(remote)
		_save_account()

func _on_account_imported(success: bool, imported: Dictionary) -> void:
	if success and not imported.is_empty():
		_merge_remote_account(imported)
		_save_account()

## Mescla em vez de substituir o dicionario inteiro, assim nenhum campo
## local sobrevivente (caso o servidor um dia deixe de enviar algum) e
## apagado por engano.
func _merge_remote_account(remote: Dictionary) -> void:
	account_data["level"] = remote.get("level", account_data.get("level", 1))
	account_data["exp"] = remote.get("exp", account_data.get("exp", 0.0))
	account_data["unspent_points"] = remote.get("unspent_points", account_data.get("unspent_points", 0))
	account_data["points"] = remote.get("points", account_data.get("points", {}))
	if remote.has("inventory"):
		account_data["inventory"] = remote.get("inventory")
	if remote.has("equipped"):
		account_data["equipped"] = remote.get("equipped")
	if remote.has("race_id") and String(remote.get("race_id", "")) != "":
		account_data["race_id"] = remote.get("race_id")
	if remote.has("weapon_id") and String(remote.get("weapon_id", "")) != "":
		account_data["weapon_id"] = remote.get("weapon_id")
	if remote.has("gold"):
		account_data["gold"] = remote.get("gold")
	_migrate_item_formats()
	_auto_assign_character_if_veteran()
	_ensure_weapon_item_equipped(String(account_data.get("weapon_id", "")))
	_sync_selection_from_account()

func _sync_account_to_server() -> void:
	if is_online:
		NetworkClient.save_account(account_data)

## Usado apos acoes que o SERVIDOR muda por conta propria (compra/venda no
## mercado: gold e inventario sao alterados direto no banco, nao pelo
## fluxo normal client-authoritative de save_account). Busca o estado
## atual e adota — nao empurra o cache local antigo por cima.
func refresh_account_from_server() -> void:
	if not is_online:
		return
	NetworkClient.account_fetch_result.connect(_on_refresh_fetched, CONNECT_ONE_SHOT)
	NetworkClient.fetch_account()

func _on_refresh_fetched(success: bool, remote: Dictionary) -> void:
	if not success or remote.is_empty():
		return
	_merge_remote_account(remote)
	_save_account()
