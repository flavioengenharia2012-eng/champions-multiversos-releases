extends Node
## Estado de uma partida coop ativa numa sala (Fase C.3), so existe no
## servidor. Autoridade sobre a wave atual e o HP de cada inimigo, por
## indice — na MESMA ordem deterministica que os clientes tambem calculam
## localmente (reaproveita wave_manager.gd: mesma seed por wave, mesmo
## sorteio ponderado, mesmo agrupamento por formacao). Os clientes so
## desenham/movem os inimigos localmente; o HP real e quem morreu vem
## sempre do servidor via MultiplayerRoom.

signal wave_advanced(wave_number, enemy_ids)
signal enemy_hp_changed(wave_number, enemy_index, hp, max_hp)
signal enemy_died(wave_number, enemy_index, exp_value, gold_value, killer_peer_id)
signal damage_totals_changed(damage_by_peer)

## Modulo puro de logica (sem preload de cena/textura nenhuma) — o servidor
## dedicado headless roda sem nenhum asset visual, entao NAO pode depender
## de wave_manager.gd (que preloada Enemy.tscn e toda a arvore de sprites
## que ele referencia).
const WAVE_COMPOSITION := preload("res://scripts/wave_composition.gd")
const CLEAR_ALL_GRACE := 2.0
## Atraso antes da Wave 1 comecar de fato. Sem isso, _advance_wave() era
## chamado sincronamente dentro de start() (disparado pelo RPC start_match,
## ANTES do RPC _on_match_started chegar aos clientes) — o broadcast da
## primeira wave saia da fila de rede antes dos clientes sequer terem
## trocado de cena pra Main.tscn e conectado o listener de
## coop_wave_advanced, entao a primeira wave nunca era desenhada em lugar
## nenhum (confirmado por teste real client-servidor via ENet).
const MATCH_START_GRACE := 2.0

var room_code := ""
var peer_ids: Array = []
var dead_peers: Dictionary = {}
var wave := 0
var wave_timer := 0.0
var enemies: Array = []  # [{type_id, hp, max_hp, exp_value, gold_value, alive}]
var damage_by_peer: Dictionary = {}  # peer_id(int) -> float
var _started := false

func start(code: String, peers: Array) -> void:
	room_code = code
	peer_ids = peers.duplicate()
	for pid in peer_ids:
		damage_by_peer[pid] = 0.0
	wave_timer = MATCH_START_GRACE

func _process(delta: float) -> void:
	wave_timer -= delta
	if not _started:
		if wave_timer <= 0.0:
			_started = true
			_advance_wave()
		return
	if wave_timer > CLEAR_ALL_GRACE and _all_enemies_dead():
		wave_timer = CLEAR_ALL_GRACE
	if wave_timer <= 0.0:
		_advance_wave()

func _all_enemies_dead() -> bool:
	for e in enemies:
		if e["alive"]:
			return false
	return true

func _advance_wave() -> void:
	wave += 1
	var stage: Dictionary = GameData.get_stage(wave)
	wave_timer = float(stage.get("duration", 18.0))
	var ids: Array = _compute_wave_enemy_list(wave, stage)
	var mult: float = float(stage.get("difficulty_mult", 1.0))
	var diff_scale: float = clamp(mult, 1.0, 6.0)
	enemies = []
	for id in ids:
		var type_data: Dictionary = GameData.get_enemy_type(id)
		if type_data.is_empty():
			continue
		var max_hp: float = float(type_data.get("base_hp", 10)) * mult
		enemies.append({
			"type_id": id,
			"hp": max_hp,
			"max_hp": max_hp,
			"exp_value": int(round(float(type_data.get("exp_value", 5)) * diff_scale)),
			"gold_value": int(round(float(type_data.get("gold_value", 1)) * diff_scale)),
			"alive": true,
		})
	## Bosses nao vem na composicao normal (_compute_wave_enemy_list) — sem
	## adiciona-los aqui tambem, wave_manager.gd:_spawn_boss no cliente
	## nunca tinha um enemy_index valido pra reportar, e cada jogador acabava
	## aplicando dano local a propria copia do boss (a vida dele nunca
	## sincronizava entre os jogadores da sala). Os dois lados calculam o
	## mesmo boss/count de forma deterministica a partir do mesmo stage_data,
	## entao os indices batem sem precisar viajar na lista `ids`.
	## Sem tipo explicito: quando o estagio nao tem boss, o campo JSON e
	## "boss": null (nao ausente) — Dictionary.get(k, default) so usa o
	## default se a CHAVE nao existir, entao aqui ele retorna o proprio null
	## armazenado, e atribuir isso a uma var tipada Dictionary quebra.
	var boss = stage.get("boss")
	if boss is Dictionary and not boss.is_empty():
		var boss_type: Dictionary = GameData.get_enemy_type(boss.get("id", ""))
		if not boss_type.is_empty():
			var boss_max_hp: float = float(boss_type.get("base_hp", 10)) * mult
			for i in range(int(boss.get("count", 1))):
				enemies.append({
					"type_id": boss.get("id", ""),
					"hp": boss_max_hp,
					"max_hp": boss_max_hp,
					"exp_value": int(round(float(boss_type.get("exp_value", 5)) * diff_scale)),
					"gold_value": int(round(float(boss_type.get("gold_value", 1)) * diff_scale)),
					"alive": true,
				})
	wave_advanced.emit(wave, ids)

## Reproduz EXATAMENTE a mesma sequencia de sorteios que wave_manager.gd
## usa no cliente (mesma seed = wave_number, mesmo pick ponderado, mesmo
## agrupamento por formacao) — sem instanciar nenhum no/fisica, so pra
## saber a lista ordenada de tipos. O servidor headless nao precisa de
## posicao/movimento, so de "quem e o inimigo no indice N".
func _compute_wave_enemy_list(wave_number: int, stage: Dictionary) -> Array:
	var rng := RandomNumberGenerator.new()
	rng.seed = wave_number
	return WAVE_COMPOSITION.compute_wave_ids(stage, rng)

## Chamado pelo servidor quando um peer reporta ter acertado um inimigo.
## Retorna true se o dano foi de fato aplicado (inimigo existia/vivo).
func apply_hit(enemy_index: int, damage: float, peer_id: int) -> bool:
	if enemy_index < 0 or enemy_index >= enemies.size():
		return false
	var e: Dictionary = enemies[enemy_index]
	if not e["alive"]:
		return false
	var applied: float = min(e["hp"], max(0.0, damage))
	e["hp"] -= applied
	damage_by_peer[peer_id] = float(damage_by_peer.get(peer_id, 0.0)) + applied
	if e["hp"] <= 0.0:
		e["alive"] = false
		enemy_died.emit(wave, enemy_index, e["exp_value"], e["gold_value"], peer_id)
	else:
		enemy_hp_changed.emit(wave, enemy_index, e["hp"], e["max_hp"])
	if applied > 0.0:
		damage_totals_changed.emit(damage_by_peer.duplicate())
	return true
