extends RefCounted
## Logica pura de "quais inimigos e em que ordem compoem uma wave", extraida
## de wave_manager.gd pra um modulo sem NENHUMA dependencia de cena/textura
## (nada de preload de .tscn aqui). Usado tanto pelo cliente (wave_manager.gd,
## que ainda cuida do spawn visual/posicionamento) quanto pelo servidor
## dedicado headless (coop_match.gd) — os dois precisam produzir EXATAMENTE
## a mesma lista pra uma dada wave/seed, e o servidor nao pode arrastar
## Enemy.tscn (e todos os sprites que ele referencia) so pra calcular isso.

const BASE_SPAWN_INTERVAL := 0.85
const MIN_ENEMY_COUNT := 10
const MAX_ENEMY_COUNT := 60

static func enemy_count_for_stage(stage_data: Dictionary) -> int:
	var interval_mult: float = float(stage_data.get("spawn_interval_mult", 1.0))
	var duration: float = float(stage_data.get("duration", 18.0))
	return clampi(
		roundi(duration / (BASE_SPAWN_INTERVAL * max(0.1, interval_mult))),
		MIN_ENEMY_COUNT,
		MAX_ENEMY_COUNT
	)

## Reagrupa a lista de sorteios (ja ponderada) em blocos de 2-4 do mesmo
## tipo, na ordem embaralhada — da a leitura de "formacao" (varios do mesmo
## monstro juntos) em vez de tipos intercalados aleatoriamente a cada spawn.
static func cluster_by_type(ids: Array, rng: RandomNumberGenerator) -> Array:
	var counts: Dictionary = {}
	for id in ids:
		counts[id] = int(counts.get(id, 0)) + 1

	var clusters: Array = []
	for id in counts.keys():
		var remaining: int = counts[id]
		while remaining > 0:
			var cluster_size: int = min(remaining, rng.randi_range(2, 4))
			clusters.append({"id": id, "count": cluster_size})
			remaining -= cluster_size

	for i in range(clusters.size() - 1, 0, -1):
		var j: int = rng.randi_range(0, i)
		var tmp = clusters[i]
		clusters[i] = clusters[j]
		clusters[j] = tmp

	var result: Array = []
	for c in clusters:
		for i in range(int(c["count"])):
			result.append(c["id"])
	return result

## Pipeline completo: sorteio ponderado (GameData.pick_weighted_enemy_id) +
## agrupamento por formacao, na ordem exata que a wave vai ser povoada.
## Determinístico pro rng passado (seedado com o numero da wave por quem
## chama) — cliente e servidor produzem sempre a mesma lista.
static func compute_wave_ids(stage_data: Dictionary, rng: RandomNumberGenerator) -> Array:
	var composition: Array = stage_data.get("composition", [])
	if composition.is_empty():
		return []
	var count := enemy_count_for_stage(stage_data)
	var picks: Array = []
	for i in range(count):
		picks.append(GameData.pick_weighted_enemy_id(composition, rng))
	return cluster_by_type(picks, rng)
