extends Node
## Ponto de entrada do servidor dedicado (Fase C): roda headless no VPS,
## abre a porta ENet e delega o gerenciamento de salas pro autoload
## MultiplayerRoom (o mesmo script usado pelo cliente, garantindo que os
## RPCs alcancem o mesmo caminho de no dos dois lados).
##
## Uso: godot --headless --path . scenes/DedicatedServer.tscn

const PORT := 9050
const MAX_CONNECTIONS := 64

func _ready() -> void:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(PORT, MAX_CONNECTIONS)
	if err != OK:
		push_error("Nao foi possivel abrir a porta %d: erro %d" % [PORT, err])
		get_tree().quit(1)
		return
	multiplayer.multiplayer_peer = peer
	multiplayer.peer_connected.connect(func(id): print("Peer conectado: ", id))
	multiplayer.peer_disconnected.connect(func(id): print("Peer desconectado: ", id))
	print("Servidor dedicado Champions dos Multiversos ouvindo na porta ", PORT)
