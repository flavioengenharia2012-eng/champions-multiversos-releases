extends Node
## Autoload NetworkClient: cliente HTTP fino para o backend de contas
## (registro/login/conta). Cada chamada cria um HTTPRequest descartavel.

signal login_result(success, message)
signal register_result(success, message)
signal account_fetch_result(success, account)
signal account_save_result(success)
signal session_verify_result(valid)
signal friends_list_result(success, data)
signal friend_request_result(success, message)
signal friend_accept_result(success)
signal friend_decline_result(success)
signal market_list_result(success, listings)
signal market_create_listing_result(success, message)
signal market_buy_result(success, message, item)
signal market_cancel_result(success, message)

const BASE_URL := "https://champions-multiversos.duckdns.org"
const SESSION_PATH := "user://session.json"

var auth_token := ""
var logged_in_username := ""

func is_logged_in() -> bool:
	return auth_token != ""

func register(username: String, password: String) -> void:
	_request("/api/auth/register", HTTPClient.METHOD_POST, {"username": username, "password": password}, false, func(ok, code, body):
		if ok and code == 201:
			auth_token = body.get("token", "")
			logged_in_username = body.get("username", "")
			save_session()
			register_result.emit(true, "")
		else:
			register_result.emit(false, str(body.get("error", "erro desconhecido")))
	)

func login(username: String, password: String) -> void:
	_request("/api/auth/login", HTTPClient.METHOD_POST, {"username": username, "password": password}, false, func(ok, code, body):
		if ok and code == 200:
			auth_token = body.get("token", "")
			logged_in_username = body.get("username", "")
			save_session()
			login_result.emit(true, "")
		else:
			login_result.emit(false, str(body.get("error", "erro desconhecido")))
	)

## ---- Sessao persistente (permanece logado apos o primeiro login) ----

func save_session() -> void:
	var f := FileAccess.open(SESSION_PATH, FileAccess.WRITE)
	f.store_string(JSON.stringify({"token": auth_token, "username": logged_in_username}))
	f.close()

## Retorna true se havia uma sessao salva (nao significa que o token ainda
## e valido — chamar verify_session() em seguida pra confirmar com o servidor).
func load_session() -> bool:
	if not FileAccess.file_exists(SESSION_PATH):
		return false
	var f := FileAccess.open(SESSION_PATH, FileAccess.READ)
	var text := f.get_as_text()
	f.close()
	var parsed = JSON.parse_string(text)
	if typeof(parsed) != TYPE_DICTIONARY or String(parsed.get("token", "")) == "":
		return false
	auth_token = parsed.get("token", "")
	logged_in_username = parsed.get("username", "")
	return true

func clear_session() -> void:
	auth_token = ""
	logged_in_username = ""
	if FileAccess.file_exists(SESSION_PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SESSION_PATH))

func verify_session() -> void:
	_request("/api/auth/verify", HTTPClient.METHOD_POST, {"token": auth_token}, false, func(ok, code, body):
		session_verify_result.emit(ok and code == 200 and bool(body.get("valid", false)))
	)

func fetch_account() -> void:
	_request("/api/account", HTTPClient.METHOD_GET, {}, true, func(ok, code, body):
		account_fetch_result.emit(ok and code == 200, body if ok else {})
	)

func save_account(account_data: Dictionary) -> void:
	_request("/api/account", HTTPClient.METHOD_PUT, account_data, true, func(ok, code, _body):
		account_save_result.emit(ok and code == 200)
	)

func import_account(account_data: Dictionary) -> void:
	_request("/api/account/import", HTTPClient.METHOD_POST, account_data, true, func(ok, code, body):
		account_fetch_result.emit(ok and code == 200, body.get("account", {}) if ok else {})
	)

## ---- Amigos ----

func fetch_friends() -> void:
	_request("/api/friends", HTTPClient.METHOD_GET, {}, true, func(ok, code, body):
		friends_list_result.emit(ok and code == 200, body if ok else {})
	)

func send_friend_request(username: String) -> void:
	_request("/api/friends/request", HTTPClient.METHOD_POST, {"username": username}, true, func(ok, code, body):
		friend_request_result.emit(ok and code == 201, "" if ok else str(body.get("error", "erro desconhecido")))
	)

func accept_friend_request(requester_id: int) -> void:
	_request("/api/friends/%d/accept" % requester_id, HTTPClient.METHOD_POST, {}, true, func(ok, code, _body):
		friend_accept_result.emit(ok and code == 200)
	)

func decline_friend_request(requester_id: int) -> void:
	_request("/api/friends/%d/decline" % requester_id, HTTPClient.METHOD_POST, {}, true, func(ok, code, _body):
		friend_decline_result.emit(ok and code == 200)
	)

## ---- Mercado ----

func fetch_market_listings() -> void:
	_request("/api/market", HTTPClient.METHOD_GET, {}, true, func(ok, code, body):
		market_list_result.emit(ok and code == 200, body.get("listings", []) if ok else [])
	)

func create_market_listing(item_uid: String, price_gold: int) -> void:
	_request("/api/market/list", HTTPClient.METHOD_POST, {"item_uid": item_uid, "price_gold": price_gold}, true, func(ok, code, body):
		market_create_listing_result.emit(ok and code == 201, "" if ok else str(body.get("error", "erro desconhecido")))
	)

func buy_market_listing(listing_id: int) -> void:
	_request("/api/market/%d/buy" % listing_id, HTTPClient.METHOD_POST, {}, true, func(ok, code, body):
		market_buy_result.emit(ok and code == 200, "" if ok else str(body.get("error", "erro desconhecido")), body.get("item", {}))
	)

func cancel_market_listing(listing_id: int) -> void:
	_request("/api/market/%d/cancel" % listing_id, HTTPClient.METHOD_POST, {}, true, func(ok, code, body):
		market_cancel_result.emit(ok and code == 200, "" if ok else str(body.get("error", "erro desconhecido")))
	)

func _request(path: String, method: HTTPClient.Method, payload: Dictionary, authed: bool, callback: Callable) -> void:
	var http := HTTPRequest.new()
	add_child(http)
	var headers := PackedStringArray(["Content-Type: application/json"])
	if authed:
		headers.append("Authorization: Bearer %s" % auth_token)
	var body_str := "" if method == HTTPClient.METHOD_GET else JSON.stringify(payload)
	var err := http.request(BASE_URL + path, headers, method, body_str)
	if err != OK:
		callback.call(false, 0, {"error": "falha ao iniciar requisicao"})
		http.queue_free()
		return
	http.request_completed.connect(func(result, code, _resp_headers, body_bytes):
		var ok: bool = result == HTTPRequest.RESULT_SUCCESS
		var parsed: Dictionary = {}
		if body_bytes.size() > 0:
			var json := JSON.new()
			if json.parse(body_bytes.get_string_from_utf8()) == OK and json.data is Dictionary:
				parsed = json.data
		callback.call(ok, code, parsed)
		http.queue_free()
	)
